import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage, ScenarioData } from '../types';
import { startRolePlayChat } from '../services/geminiService';
import { Chat, GenerateContentResponse } from '@google/genai';
import { Mic, ArrowLeft, Volume2 } from './Icons';

interface RolePlayViewProps {
  scenario: ScenarioData;
  onExit: () => void;
}

const RolePlayView: React.FC<RolePlayViewProps> = ({ scenario, onExit }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [chatSession, setChatSession] = useState<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Initialize chat
  useEffect(() => {
    const chat = startRolePlayChat(scenario);
    setChatSession(chat);
    
    // Initial greeting from AI
    const init = async () => {
      setIsLoading(true);
      try {
        const response: GenerateContentResponse = await chat.sendMessage({ message: "Start the conversation." });
        if (response.text) {
          setMessages([{
            id: 'init',
            role: 'model',
            text: response.text
          }]);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setIsLoading(false);
      }
    };
    init();
  }, [scenario]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!inputValue.trim() || !chatSession || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: inputValue
    };

    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setIsLoading(true);

    try {
      const response: GenerateContentResponse = await chatSession.sendMessage({ message: userMsg.text });
      if (response.text) {
        const aiMsg: ChatMessage = {
          id: (Date.now() + 1).toString(),
          role: 'model',
          text: response.text
        };
        setMessages(prev => [...prev, aiMsg]);
      }
    } catch (error) {
      console.error("Chat Error", error);
      setMessages(prev => [...prev, { id: 'err', role: 'model', text: "Sorry, I couldn't respond. Try again.", isError: true }]);
    } finally {
      setIsLoading(false);
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  };

  return (
    <div className="flex flex-col h-[100dvh] bg-slate-50 dark:bg-slate-900">
      {/* Header */}
      <div className="flex-none p-4 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 flex items-center gap-3">
        <button onClick={onExit} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-full">
          <ArrowLeft />
        </button>
        <div>
            <h2 className="font-bold text-slate-800 dark:text-slate-100">Roleplay</h2>
            <p className="text-xs text-slate-500">{scenario.topic_en}</p>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] p-3 rounded-2xl shadow-sm text-sm ${
              msg.role === 'user' 
              ? 'bg-primary text-white rounded-tr-none' 
              : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-tl-none border border-slate-100 dark:border-slate-700'
            }`}>
              {msg.text}
              {msg.role === 'model' && (
                 <button 
                   onClick={() => {
                     const u = new SpeechSynthesisUtterance(msg.text);
                     u.lang = 'en-US';
                     window.speechSynthesis.speak(u);
                   }}
                   className="ml-2 align-middle inline-block opacity-50 hover:opacity-100"
                 >
                   <Volume2 size={14} />
                 </button>
              )}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
             <div className="bg-white dark:bg-slate-800 p-3 rounded-2xl rounded-tl-none border border-slate-100 dark:border-slate-700">
                <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-75"></div>
                    <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-150"></div>
                </div>
             </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="flex-none p-4 bg-white dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 safe-area-bottom">
        <div className="flex items-center gap-2">
            <button className="p-3 text-slate-400 hover:text-primary transition-colors">
                <Mic />
            </button>
            <input
                ref={inputRef}
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Type your reply..."
                className="flex-1 bg-slate-100 dark:bg-slate-900 border-0 rounded-full px-4 py-3 text-sm focus:ring-2 focus:ring-primary outline-none dark:text-white"
            />
            <button 
                onClick={handleSend}
                disabled={!inputValue.trim() || isLoading}
                className="bg-primary disabled:opacity-50 text-white p-3 rounded-full shadow-md shadow-primary/30"
            >
                <ArrowLeft className="rotate-180" />
            </button>
        </div>
      </div>
    </div>
  );
};

export default RolePlayView;