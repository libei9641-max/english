import React, { useState } from 'react';
import { ScenarioData, DialogueLine } from '../types';
import AudioPlayer from './AudioPlayer';
import { Mic, Check, BookOpen, Copy, ArrowLeft } from './Icons';

interface ScenarioViewProps {
  data: ScenarioData;
  onBack: () => void;
  onRolePlay: () => void;
}

const ScenarioView: React.FC<ScenarioViewProps> = ({ data, onBack, onRolePlay }) => {
  const [activeTab, setActiveTab] = useState<'dialogue' | 'vocab' | 'practice'>('dialogue');
  const [activeLineIndex, setActiveLineIndex] = useState<number | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<{ [key: number]: string }>({});
  const [quizFeedback, setQuizFeedback] = useState<{ [key: number]: boolean | null }>({});
  const [copyStatus, setCopyStatus] = useState(false);

  const handleCheckQuiz = (index: number, correctAnswer: string) => {
    const isCorrect = (quizAnswers[index] || '').trim().toLowerCase() === correctAnswer.toLowerCase();
    setQuizFeedback({ ...quizFeedback, [index]: isCorrect });
  };

  const handleCopyContent = async () => {
    // Create a readable text format for WeChat sharing/notes
    let content = `📝 LingoFlow Study Note: ${data.topic_en} (${data.topic_cn})\n\n`;
    
    content += `🗣️ Dialogues:\n`;
    data.dialogues.forEach(d => {
        content += `${d.speaker}: ${d.text}\n(${d.translation})\n\n`;
    });
    
    content += `📚 Vocabulary:\n`;
    data.vocabulary.forEach(v => {
        content += `• ${v.word} /${v.ipa}/: ${v.meaning}\n  Eg: ${v.example}\n\n`;
    });

    try {
        await navigator.clipboard.writeText(content);
        setCopyStatus(true);
        setTimeout(() => setCopyStatus(false), 2000);
    } catch (err) {
        alert("Unable to copy automatically. Please select text manually.");
    }
  };

  // Simulated Pronunciation Scoring
  const [recordingState, setRecordingState] = useState<{ [key: number]: 'idle' | 'recording' | 'scored' }>({});
  const [scores, setScores] = useState<{ [key: number]: number }>({});

  const toggleRecord = (index: number) => {
    const current = recordingState[index] || 'idle';
    if (current === 'idle') {
      setRecordingState({ ...recordingState, [index]: 'recording' });
      // Mock recording duration
      setTimeout(() => {
        setRecordingState({ ...recordingState, [index]: 'scored' });
        // Mock score 70-98
        setScores({ ...scores, [index]: Math.floor(Math.random() * (98 - 70) + 70) });
      }, 2000);
    } else if (current === 'scored') {
        setRecordingState({ ...recordingState, [index]: 'idle' });
    }
  };

  return (
    <div className="bg-slate-50 dark:bg-slate-900 min-h-screen pb-safe">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white/90 dark:bg-slate-800/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 px-4 py-3 pt-safe flex items-center justify-between shadow-sm">
        <button onClick={onBack} className="text-slate-600 dark:text-slate-300 p-1 active:opacity-60">
          <ArrowLeft />
        </button>
        <div className="flex flex-col items-center max-w-[60%]">
            <h1 className="font-bold text-lg truncate w-full text-center text-slate-800 dark:text-white">{data.topic_en}</h1>
            <span className="text-xs text-slate-500 dark:text-slate-400 truncate w-full text-center">{data.topic_cn}</span>
        </div>
        <div className="flex items-center gap-2">
            <button 
                onClick={handleCopyContent} 
                className={`p-2 rounded-full transition-all ${copyStatus ? 'bg-green-100 text-green-600' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'}`}
                title="Copy to Clipboard"
            >
                {copyStatus ? <Check size={20} /> : <Copy size={20} />}
            </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex p-2 gap-2 bg-white dark:bg-slate-800 shadow-sm mb-4 sticky top-[60px] z-10">
        {[
            { id: 'dialogue', label: 'Dialogue' }, 
            { id: 'vocab', label: 'Words' }, 
            { id: 'practice', label: 'Practice' }
        ].map(tab => (
            <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex-1 py-2 text-sm font-medium rounded-lg transition-colors ${
                    activeTab === tab.id 
                    ? 'bg-primary text-white shadow-md' 
                    : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700'
                }`}
            >
                {tab.label}
            </button>
        ))}
      </div>

      {/* Content Area */}
      <div className="px-4 pb-20 space-y-6 max-w-2xl mx-auto selectable-text">
        
        {/* Dialogue View */}
        {activeTab === 'dialogue' && (
          <div className="space-y-4">
            {data.dialogues.map((line, idx) => (
              <div 
                key={idx} 
                className={`p-4 rounded-xl transition-all cursor-pointer border ${
                  activeLineIndex === idx 
                  ? 'bg-white dark:bg-slate-800 border-primary ring-1 ring-primary' 
                  : 'bg-white dark:bg-slate-800 border-transparent active:bg-slate-100 dark:active:bg-slate-700 shadow-sm'
                }`}
                onClick={() => setActiveLineIndex(idx)}
              >
                <div className="flex justify-between items-start mb-1">
                  <span className="text-xs font-bold text-secondary uppercase tracking-wide">{line.speaker}</span>
                </div>
                <p className="text-lg font-medium text-slate-800 dark:text-slate-100 leading-relaxed">{line.text}</p>
                {activeLineIndex === idx && (
                  <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-700 animate-fadeIn">
                    <p className="text-sm text-slate-500 dark:text-slate-400 mb-3">{line.translation}</p>
                    <div className="flex items-center justify-between">
                        <AudioPlayer text={line.text} />
                        <div className="flex items-center gap-2">
                            {recordingState[idx] === 'scored' && (
                                <span className={`text-sm font-bold ${scores[idx] > 85 ? 'text-green-500' : 'text-amber-500'}`}>
                                    {scores[idx]}%
                                </span>
                            )}
                            <button 
                                onClick={(e) => { e.stopPropagation(); toggleRecord(idx); }}
                                className={`p-3 rounded-full transition-colors ${
                                    recordingState[idx] === 'recording' 
                                    ? 'bg-red-100 text-red-600 animate-pulse' 
                                    : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                                }`}
                            >
                                <Mic size={20} />
                            </button>
                        </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
            
            <div className="pt-8 pb-safe">
                <button 
                    onClick={onRolePlay}
                    className="w-full bg-gradient-to-r from-primary to-indigo-600 text-white py-4 rounded-xl font-bold shadow-lg shadow-primary/20 flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
                >
                    <span>Start AI Roleplay</span>
                </button>
            </div>
          </div>
        )}

        {/* Vocabulary View */}
        {activeTab === 'vocab' && (
            <div className="grid gap-4">
                {data.vocabulary.map((v, idx) => (
                    <div key={idx} className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700">
                        <div className="flex justify-between items-start">
                            <div>
                                <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100">{v.word}</h3>
                                <span className="text-sm font-mono text-slate-500">/{v.ipa}/</span>
                                <span className="ml-2 text-xs bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded text-slate-600 dark:text-slate-300">{v.partOfSpeech}</span>
                            </div>
                            <AudioPlayer text={v.word} />
                        </div>
                        <p className="mt-2 text-slate-700 dark:text-slate-300">{v.meaning}</p>
                        <div className="mt-3 p-3 bg-slate-50 dark:bg-slate-900/50 rounded-lg border border-slate-100 dark:border-slate-700/50">
                            <p className="text-sm italic text-slate-600 dark:text-slate-400">"{v.example}"</p>
                            <p className="text-xs text-slate-500 dark:text-slate-500 mt-1 border-t border-slate-200 dark:border-slate-700 pt-1">{v.example_translation}</p>
                        </div>
                    </div>
                ))}
            </div>
        )}

        {/* Practice View */}
        {activeTab === 'practice' && (
            <div className="space-y-6 pb-safe">
                <div className="bg-indigo-50 dark:bg-indigo-900/20 p-4 rounded-xl border border-indigo-100 dark:border-indigo-800">
                    <h3 className="font-bold text-indigo-900 dark:text-indigo-200 mb-2 flex items-center gap-2">
                        <BookOpen size={18}/> 
                        Fill in the Blanks
                    </h3>
                    <div className="space-y-6 mt-4">
                        {data.quiz.map((q, idx) => (
                            <div key={idx} className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-sm">
                                <p className="text-sm text-slate-500 mb-2">{q.context}</p>
                                <p className="text-lg font-medium mb-3 leading-loose">
                                    {q.question.split('______').map((part, i, arr) => (
                                        <React.Fragment key={i}>
                                            {part}
                                            {i < arr.length - 1 && (
                                                <input
                                                    type="text"
                                                    value={quizAnswers[idx] || ''}
                                                    onChange={(e) => setQuizAnswers({...quizAnswers, [idx]: e.target.value})}
                                                    className={`mx-1 border-b-2 w-24 text-center outline-none bg-transparent p-1 ${
                                                        quizFeedback[idx] === true ? 'border-green-500 text-green-600' : 
                                                        quizFeedback[idx] === false ? 'border-red-500 text-red-600' : 'border-slate-300 dark:border-slate-600 focus:border-primary'
                                                    }`}
                                                    placeholder="..."
                                                    autoComplete="off"
                                                />
                                            )}
                                        </React.Fragment>
                                    ))}
                                </p>
                                <div className="flex justify-end">
                                    {quizFeedback[idx] !== true && (
                                        <button 
                                            onClick={() => handleCheckQuiz(idx, q.answer)}
                                            className="text-sm bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-4 py-2 rounded-lg font-medium active:opacity-80"
                                        >
                                            Check
                                        </button>
                                    )}
                                    {quizFeedback[idx] === true && (
                                        <span className="text-green-600 flex items-center gap-1 text-sm font-bold">
                                            <Check size={16}/> Correct
                                        </span>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        )}
      </div>
    </div>
  );
};

export default ScenarioView;