import React, { useState, useEffect } from 'react';
import { Volume2 } from './Icons';

interface AudioPlayerProps {
  text: string;
  autoPlay?: boolean;
}

const AudioPlayer: React.FC<AudioPlayerProps> = ({ text, autoPlay = false }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [rate, setRate] = useState(1.0);
  const [accent, setAccent] = useState<'US' | 'UK'>('US');
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);

  useEffect(() => {
    const loadVoices = () => {
      const availableVoices = window.speechSynthesis.getVoices();
      setVoices(availableVoices);
    };
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
  }, []);

  const speak = () => {
    window.speechSynthesis.cancel(); // Stop previous
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Attempt to match accent
    const langCode = accent === 'US' ? 'en-US' : 'en-GB';
    const voice = voices.find(v => v.lang === langCode && v.name.includes(accent === 'US' ? 'Google' : 'English'));
    if (voice) utterance.voice = voice;
    else utterance.lang = langCode;

    utterance.rate = rate;
    
    utterance.onstart = () => setIsPlaying(true);
    utterance.onend = () => setIsPlaying(false);
    utterance.onerror = () => setIsPlaying(false);

    window.speechSynthesis.speak(utterance);
  };

  useEffect(() => {
    if (autoPlay) speak();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoPlay]);

  return (
    <div className="flex items-center space-x-2 mt-2 p-2 bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm">
      <button 
        onClick={speak} 
        className={`p-2 rounded-full ${isPlaying ? 'bg-primary text-white' : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'}`}
      >
        <Volume2 size={18} />
      </button>
      
      <div className="flex flex-col space-y-1">
        <div className="flex space-x-2 text-xs font-medium">
          <button 
            onClick={() => setAccent('US')}
            className={`px-2 py-0.5 rounded ${accent === 'US' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300' : 'text-slate-500'}`}
          >
            US
          </button>
          <button 
             onClick={() => setAccent('UK')}
             className={`px-2 py-0.5 rounded ${accent === 'UK' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300' : 'text-slate-500'}`}
          >
            UK
          </button>
        </div>
        
        <div className="flex space-x-1 text-[10px] text-slate-500">
          {[0.8, 1.0, 1.2].map(s => (
            <button
              key={s}
              onClick={() => setRate(s)}
              className={`px-1.5 rounded border ${rate === s ? 'border-primary text-primary bg-primary/5' : 'border-transparent hover:bg-slate-100 dark:hover:bg-slate-700'}`}
            >
              {s}x
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AudioPlayer;