import { GoogleGenAI, Type, Schema } from "@google/genai";
import { ScenarioData } from "../types";

const API_KEY = process.env.API_KEY || '';

// Helper to check API Key
export const hasApiKey = () => !!API_KEY;

const ai = new GoogleGenAI({ apiKey: API_KEY });

// Define schema for structured scenario generation
const scenarioSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    topic_en: { type: Type.STRING, description: "English title of the scenario" },
    difficulty: { type: Type.STRING, description: "Overall difficulty level" },
    dialogues: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          speaker: { type: Type.STRING, description: "Name of speaker (e.g., Server, Customer)" },
          text: { type: Type.STRING, description: "English text" },
          translation: { type: Type.STRING, description: "Chinese translation" },
        },
        required: ["speaker", "text", "translation"]
      }
    },
    vocabulary: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          word: { type: Type.STRING },
          ipa: { type: Type.STRING },
          meaning: { type: Type.STRING },
          partOfSpeech: { type: Type.STRING },
          example: { type: Type.STRING, description: "Short example sentence using the word in context" },
          example_translation: { type: Type.STRING, description: "Chinese translation of the example sentence" }
        },
        required: ["word", "ipa", "meaning", "partOfSpeech", "example", "example_translation"]
      }
    },
    quiz: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          question: { type: Type.STRING, description: "A fill-in-the-blank sentence with the word missing" },
          answer: { type: Type.STRING, description: "The missing word" },
          context: { type: Type.STRING, description: "Hint or translation" }
        }
      }
    }
  },
  required: ["topic_en", "dialogues", "vocabulary", "quiz"]
};

export const generateScenario = async (topic: string): Promise<ScenarioData | null> => {
  try {
    const model = "gemini-2.5-flash";
    
    const prompt = `
      Generate a comprehensive English learning scenario for the topic: "${topic}".
      Target audience: Chinese speakers learning English.
      
      Requirements:
      1. Create a realistic dialogue (6-10 turns) suitable for the scenario.
      2. Ensure the English is natural and idiomatically correct for the context.
      3. Extract 4-6 key vocabulary words.
      4. Create 2 fill-in-the-blank quiz questions based on the dialogue.
      5. Difficulty should adapt to the complexity of the topic but generally target Intermediate (B1/B2).
    `;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: scenarioSchema,
        systemInstruction: "You are an expert English curriculum designer.",
      },
    });

    if (response.text) {
      const data = JSON.parse(response.text);
      return {
        id: Date.now().toString(),
        topic_cn: topic,
        ...data
      };
    }
    return null;
  } catch (error) {
    console.error("GenAI Error:", error);
    throw error;
  }
};

export const startRolePlayChat = (scenarioContext: ScenarioData) => {
  return ai.chats.create({
    model: "gemini-2.5-flash",
    config: {
      systemInstruction: `
        You are a roleplay partner. 
        Scenario: ${scenarioContext.topic_en}.
        Your Goal: Act as a character in this scenario. Engage the user in conversation.
        Correction Policy: If the user makes a significant grammar mistake, politely correct them in parentheses at the end of your response, but keep the conversation flowing naturally.
        Keep responses concise (under 30 words) to encourage back-and-forth.
      `
    }
  });
};